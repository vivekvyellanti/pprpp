from main import db,ecat,Category

db.create_all()


ncat = Category("Mechanical fasteners")
ncat2 = Category("Binders")

db.session.add_all([ncat,ncat2])

db.session.commit()

